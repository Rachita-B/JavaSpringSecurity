create database springsecuritydemo1;
Select *from user;
Select *from authorities;
-- insert into  user values (1,"password123","ravi@coding.com");
-- insert into  user values (2,"123","rachita@coding.com");

Drop table user;
drop table authorities;
insert into  authorities values (10,"ADMIN",1);
insert into  authorities values (12,"USER",2);
insert into user (username,password) values ('rachita@codr.com','$2a$10$WrFrAbTWerL/Rlb7SXadUOzU1NU1vWOYkgSKolxsvELiHeV0nAU/W'); -- password123 -- erun testing files run as junit to find encrypted passwords
insert into user (username,password) values('Ram@gmail.com',"$2a$10$hlg00gP.ChKPY.V6gYAOCe7OSX3qQ34b8iOj4yjpfi4jTVNo/EYjW");  -- ram@123 --have to store encrypted password here
insert into authorities(authority,user_id) values ('ROLE_USER',1); -- have to set role like this ROLE_ADMIN,ROLE_USER,ROLE_AnythingWhatMentioned
insert into authorities(authority,user_id) values ('ROLE_USER',2);
update authorities set authority='ROLE_USER' where id=1;
insert into  authorities values ("ROLE_ADMIN",1); -- not working add 3 coloumns value
insert into authorities(authority,user_id) values ('ROLE_ADMIN',1);
Delete from authorities where id =3;