package com.springsecurityexample.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;

import com.springsecurityexample.domain.User;
import com.springsecurityexample.service.AdminService;
/*
@Controller
public class DashboardController {
  @GetMapping("/dashboard")
  public String getDashboard () {
    return "dashboard";
  }
}
*/
///calling user object in controller and show object details on back end 
/*
  @Controller
public class DashboardController {
  @GetMapping("/dashboard")
  public String getDashboard(@AuthenticationPrincipal User user) {
	  System.out.println(user);
	  System.out.println(user.getId());
	  System.out.println(user.getPassword());
	  System.out.println(user.getUsername());
	 
    return "dashboard";
  }
}
 */
/*
// show object details on front end 
//put on dashboard.html page also to show on frontend <p th:text="| Hello there ${user.username} |"></p>
@Controller
public class DashboardController {
  @GetMapping("/dashboard")
  public String getDashboard(@AuthenticationPrincipal User user, ModelMap model) {
	  System.out.println(user); // show on back end
	 
	  model.put("user", user);  // show on front end 
    return "dashboard";
  }
}
*/
// method level security for admin service method will execute only if  user  have role admin

@Controller
public class DashboardController {
  
  @Autowired
  private AdminService adminService;
  
  @GetMapping("/dashboard")
  public String getDashboard (@AuthenticationPrincipal User user, ModelMap model) {
    System.out.println(user);
    
    model.put("user", user);
    List<User> allUserAccounts = adminService.getAllUserAccounts();
    
    return "dashboard";
  }
}