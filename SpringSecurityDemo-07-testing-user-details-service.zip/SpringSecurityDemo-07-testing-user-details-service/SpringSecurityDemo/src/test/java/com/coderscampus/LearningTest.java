package com.coderscampus;

import org.junit.Test;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

public class LearningTest {
  
  @Test
  public void encrypt_password () {
    PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
    
    String encodedPassword = passwordEncoder.encode("password123");
    String encodedPassword1 = passwordEncoder.encode("ram@123");
    System.out.println("encodedPassword=: "+encodedPassword);
    System.out.println("encodedPassword1=: "+encodedPassword1); // save encoded password in database and in UI frontend enter above password to login
  }
}
